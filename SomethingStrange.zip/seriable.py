import json
import pickle
import urllib2
from bs4 import BeautifulSoup
import csv
import random
import time
# info={u'name':u'Tom',
#       u'age':u'12',
#       u'job':u'work',}
# with open('tmp.pk', 'w') as f:
#     pickle.dump(info, f)

def getCompanyName(value):
    a = random.uniform(1,5.5)
    time.sleep(a)
    try:
        c = 'https://www.tianyancha.com/search?key='

        user_agent = 'Mozilla/4.0 (compatible; MSIE 5.5; Windows NT)'
        headers = {'User-Agent': user_agent}
        request = urllib2.Request(c+value, headers = headers)
        response = urllib2.urlopen(request)
        page = response.read()
        soup = BeautifulSoup(page, "lxml")
        a = soup.find("div", class_='left-item ')
        a = a.img['alt']
        print a
    except:
        a = ''
        print('get error')
    return value, a

def replace(str):
    for i in str:
        if i.isalpha() or i.isdigit():
            continue
        else:
            return False
    return True


if __name__ == '__main__':
    csv_file = csv.reader(open('company_code_known.csv', 'r'))
    code_list = []
    dic = {}
    for i in csv_file:
        if i[0] not in code_list and replace(i[0]):
            code_list.append(i[0])
    print len(code_list)
    for item in code_list:
        name = getCompanyName(item)
        if len(name):
            dic[item] = name
    with open('Known_tmp.pk', 'w') as f:
        pickle.dump(dic, f)


