# -*- coding: utf-8 -*-
import json
import os
import codecs
import time
import xlwt
import xlrd
import csv
import re
import pickle

def readCSVfile():
    result = []
    real_result = []
    filename = 'CompanyList.csv'
    with open(filename, 'r') as f:
        csv_file = csv.reader(f)
        for i in csv_file:
            result.append(i[0].decode('utf-8'))
    for i in result:
        i = i.strip()
        i = re.sub(r'\\n|\\',u'',i)
        i = re.sub(r'[0-9]|:|,|[A-Z]|[a-z]|\[|\]|\-',u'',i)
        if len(i.strip()) <= 5:
            continue
        if not i in real_result:
            real_result.append(i)
    for it in real_result:
        print 'u\''+it+'\''+','

def reafTXTfile():
    filename = ['company1_2.txt', 'company3.txt', 'company4.txt', 'company5_part.txt']
    num = 0
    total = 0
    company_list = []
    for file_name in filename:
        with open(file_name, 'r') as f:
            line =f.readline()
            while line:
                line = line.strip()
                rre = u'法人代表'
                if not rre in line.decode('utf-8'):
                    company_list.append(line)
                line = f.readline()
        #w = float(num)/(float(total)/2)
    check_name = '杭州睿琪有限公司'
    print len(company_list)
    start_time = time.time()
    for it in company_list:
        if check_name == it:
            print 'yes'
    end_time = time.time()
    print '查询时间：'+str(end_time - start_time)
    #for i in company_list:
        #print type(i)
    #    print 'u\''+i+'\','



def readCompanyFile(companyFileName):
    file_name = companyFileName
    company_list = set()
    num_dic_com = {}
    rre = u'法人代表'
    company_name = ''
    company_num = ''
    for i in file_name:
        print "read file:"+i
        with open(i, 'r') as f:
            line = f.readline()
            while line:
                line = line.strip().decode('utf-8')
                if not rre in line:
                    company_name = line
                    company_list.add(company_name)
                elif re.match(rre, line):
                    split_list = re.split(u'/', line)
                    if len(split_list) > 1:
                        company_num = split_list[1].strip()
                        num_dic_com[company_num] = company_name
                    company_num = ''
                    company_name = ''
                else:
                    split_list = re.split(rre, line)
                    if len(split_list) > 1:
                        company_name = split_list[0]
                        # if company_name not in company_list:
                        #     company_list.append(company_name)
                        company_list.add(company_name)
                        split_list = re.split(u'/', split_list[1])
                        if len(split_list) > 1:
                            company_num = split_list[1].strip()
                            num_dic_com[company_num] = company_name
                    company_num = ''
                    company_name = ''

                line = f.readline()
    print len(company_list)
    a = u'鞍山苏宁云商销售有限公司'
    if a in company_list:
        print 'in'
    c = u'913201177217886352'
    print num_dic_com[c]
    print len(num_dic_com)
    with open('tmp.pk', 'w') as f:
        pickle.dump(num_dic_com, f)
    with open('company_tmp.pk', 'w') as f:
        pickle.dump(company_list, f)


if __name__ == '__main__':
    #readfile()
    file_list = ['city/company1_2.txt',
                 'city/company3.txt',
                 'city/company4.txt',
                 'city/company5_part.txt',
                 'city/company5_part2.txt',
                 'city/company5_part3.txt',
                 'city/company6_9.txt',
                 'city/company9.txt',
                 'city/company10_22_part.txt',
                 'city/company_test.txt',
                 #'city/company_known_list.txt'
                 ]
    file_a = ['city/company6_9.txt']
    readCompanyFile(file_list)

