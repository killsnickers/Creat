# -*- coding: utf-8 -*-
import os
import re
import sys
import json
import os
import xlwt
import time
import pickle
import difflib
import Levenshtein
class sero():
    def __init__(self):
        self.__WordsPatterns__ = (
        u'壹', u'贰', u'叁', u'肆', u'伍', u'陆', u'柒', u'捌', u'玖', u'零', u'拾', u'佰', u'仟', u'万', u'亿')
        self.__Suffix__ = (u'整', u'元', u'圆')
        self.__Num__ = {u'壹': 1, u'贰': 2, u'叁': 3,
                          u'肆': 4, u'伍': 5, u'陆': 6,
                          u'柒': 7, u'捌': 8, u'玖': 9,
                          u'零': 0}
        self.__Sit__ = {u'拾': 10, u'佰': 100, u'仟': 1000 }
        self.__Large__ = {u'万': 10000, }
        self.__SuperLarge__ = {u'亿': 100000000}
    def __inThousands__(self, amountin):
        number = 0
        current_number = 1
        if not len(amountin):
            return 0
        if amountin[0] not in self.__Num__ and amountin[0] != u'拾':
            return -1
        for index in range(len(amountin)):
            if self.__Num__.has_key(amountin[index]):
                current_number = self.__Num__.get(amountin[index])
            elif self.__Sit__.has_key(amountin[index]):
                current_number = current_number * self.__Sit__.get(amountin[index])
                number += current_number
                current_number = 0
            else:
                return -1
        number = number + current_number

        return number

    def __SplitAmount__(self, amount):
        num = 0
        suffix = 0
        superlarge = 0
        fields = re.split(u'(元|圆|万|亿|整|角|分)', amount)
        for item in fields:
            print item
            if item == u'万':
                num = num + suffix
                num = num * 10000
            elif item == u'亿':
                superlarge = superlarge + suffix
                superlarge = superlarge*100000000
            elif item == u'元' or item == u'圆':
                num = num + suffix
            elif item == u'角':
                num = num + suffix * 0.1
            elif item == u'分':
                num = num + suffix * 0.01
            elif item == u'整':
                continue
            else:
                suffix = self.__inThousands__(item)
                if suffix == -1:
                    return 0
        return num+superlarge


if __name__ == '__main__':
    #se = sero()
    #a = se.__SplitAmount__(u'壹拾壹万零肆佰壹拾捌圆壹角壹分')
    #print a
    # def __replaceComma__(data):
    #     data =re.sub(u'\'', u'', data)
    #     return data
    # a = u'Xi\'anbei'
    # print __replaceComma__(a)

    # start = time.time()
    # with open('tmp.pk', 'r') as f:
    #     data = pickle.load(f)
    # end = time.time()
    # print end - start
    # c = u'91610600MA6YEKKFXF'
    # print data[c]
    # end = time.time()
    # print end-start
    name = u''
    code_name = u'中国石化销售有限公司贵州黔西南安龙石油分公司'
    a = Levenshtein.ratio(name,code_name)
    print(a)