import cv2
import numpy
from ImageHandler import ImageHandler

class Point(object):
    def __init__(self, x, y):
        self.x = x
        self.y = y

class Vector(object):
    def __init__(self, A, B):
        if isinstance(A, Point) and isinstance(B, Point):
            self.x = A.x - B.x
            self.y = A.y - B.y
        else:
            self.x = A
            self.y = B

def Negative(vector):
    return Vector(vector.y, vector.x)
 
def Cross(vectorA, vectorB):
    return vectorA.x * vectorB.y - vectorB.x * vectorA.y
 
def Intersected(A, B, C, D):
    AC = Vector(A, C)
    AD = Vector(A, D)
    BC = Vector(B, C)
    BD = Vector(B, D)
    CA = Negative(AC)
    CB = Negative(BC)
    DA = Negative(AD)
    DB = Negative(BD)
 
    return ((Cross(AC, AD) * Cross(BC, BD) <= 1e-9)
        and (Cross(CA, CB) * Cross(DA, DB) <= 1e-9))

class Cv2FindSplitline(ImageHandler):
    """description of class"""

    def __init__(self):
        pass


    def __Handler__(self, image):
        if not isinstance(image, numpy.ndarray):
            return False, (image)

        if not self.__IsCv2Image__(image):
            return False, (image)

        gray = cv2.cvtColor(image, cv2.COLOR_BGR2GRAY)
        bw = cv2.adaptiveThreshold(~gray, 255, cv2.ADAPTIVE_THRESH_MEAN_C, cv2.THRESH_BINARY, 15, -2)

        im2, contours, hierarchy = cv2.findContours(bw, cv2.RETR_EXTERNAL, cv2.CHAIN_APPROX_SIMPLE)

        minarea = bw.shape[0] * bw.shape[1] * 0.001

        approxCurves = []
        boundRects = []

        for contour in contours:
            area = cv2.contourArea(contour)
            if area < minarea:
                continue

            approxCurve = cv2.approxPolyDP(contour, 3, True)
            approxCurves.append(approxCurve)

            boundRect = cv2.boundingRect(approxCurve)
            boundRects.append(boundRect)

            cv2.rectangle(image, (boundRect[0], boundRect[1]), (boundRect[0] + boundRect[2], boundRect[1] + boundRect[3]), (0, 255, 0))

        contourCountPreRow = []
        for row in range(0, bw.shape[0]):
            contourCountPreRow.append(0)

        start = int(bw.shape[0] * 0.2)
        end = int(bw.shape[0] * 0.8)
        for row in range(start, end):
            for index in range(0, len(boundRects)):
                if boundRects[index][1] < row and (boundRects[index][1] + boundRects[index][3]) > row:
                    contourCountPreRow[row] += 1

        continueSubVector = []
        currentContinueSub = 1
        for index in range(1, len(contourCountPreRow)):
            if contourCountPreRow[index] != 0 and contourCountPreRow[index] >= contourCountPreRow[index - 1]:
                    currentContinueSub += 1
                    continue

            if currentContinueSub > 1:
                continueSubVector.append((contourCountPreRow[index - 1], currentContinueSub, index - 1 - currentContinueSub, index - 1))

            currentContinueSub = 1

        if len(continueSubVector) <= 1:
            return False, (image)

        continueSubVector = sorted(continueSubVector, key = lambda x: x[1], reverse = True)

        hitRows = [continueSubVector[0][2], continueSubVector[0][3], continueSubVector[1][2], continueSubVector[1][3]]
        hitRows.sort()

        findSpace = False
        spaceStart = hitRows[2]
        spaceEnd = hitRows[1]

        if abs(spaceStart - spaceEnd) < 4:
            return False, (image)

        for row in range(hitRows[1], hitRows[2]):
            if contourCountPreRow[row] == 0:
                findSpace = True
                spaceStart = min(spaceStart, row)
                spaceEnd = max(spaceEnd, row)

        if findSpace:
            lineHeight = (spaceStart + spaceEnd) / 2
            cv2.line(image, (0, lineHeight), (bw.shape[1], lineHeight), (0, 0, 255), 1, 8, 0)

            return True, (image[0 : lineHeight, 0 : bw.shape[1]], image[lineHeight : bw.shape[0], 0 : bw.shape[1]])

        elif False:
            boundRectPoints = []
            for boundRect in boundRects:
                tl = Point(boundRect[0], boundRect[1])
                tr = Point(boundRect[0] + boundRect[2], boundRect[1])
                bl = Point(boundRect[0], boundRect[1] + boundRect[3])
                br = Point(boundRect[0] + boundRect[2], boundRect[1] + boundRect[3])
                boundRectPoints.append((tl, tr, bl, br))

            for left in range(hitRows[0], hitRows[3], 3):
                for right in range(hitRows[0], hitRows[3], 3):
                    leftPoint = Point(0, left)
                    rightPoint = Point(bw.shape[1], right)

                    isIntersected = False
                    for boundRect in boundRectPoints:
                        if (Intersected(boundRect[0], boundRect[1], leftPoint, rightPoint) or
                            Intersected(boundRect[0], boundRect[2], leftPoint, rightPoint) or
                            Intersected(boundRect[2], boundRect[3], leftPoint, rightPoint) or
                            Intersected(boundRect[1], boundRect[3], leftPoint, rightPoint)):
                            isIntersected = True
                            break

                    if not isIntersected:
                            cv2.line(image, (0, leftPoint.y), (bw.shape[1], rightPoint.y), (0, 0, 255), 1, 8, 0)
                            return True, (image) 

        return False, (image)