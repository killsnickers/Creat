import cv2
import os
import numpy

from ImageHandler import ImageHandler

class Cv2ImageRead(object):
    """description of class"""

    @staticmethod
    def Handler(filename):
        if not os.path.exists(filename):
            return None

        return cv2.imread(filename)


class Cv2ImageWrite(ImageHandler):
    """description of class"""
    def __init__(self, filename):
        self.filename = filename

    def __Handler__(self, image):
        if not isinstance(image, numpy.ndarray) or not self.__IsCv2Image__(image):
            return False, image

        cv2.imwrite(self.filename, image)
        return True, image


class Cv2ImageShow(ImageHandler):
    """description of class"""

    def __Handler__(self, image):
        if not isinstance(image, numpy.ndarray) or not self.__IsCv2Image__(image):
            return False, image

        cv2.imshow('image', image)
        cv2.waitKey()
        return True, image