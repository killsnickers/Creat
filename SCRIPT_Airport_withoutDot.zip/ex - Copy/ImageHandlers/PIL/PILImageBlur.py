from PIL import ImageFilter
import random

from ImageHandler import ImageHandler


class PILImageBlur(ImageHandler):
    """description of class"""
    def __init__(self, radius = (1, 5)):
        self.radius = radius


    def __Handler__(self, image):
        if image == None:
            return False, None

        if not self.__IsPILImage__(image):
            return False, image

        return True, image.filter(ImageFilter.GaussianBlur(radius = int(random.uniform(self.radius[0], self.radius[1]))))