from PIL import Image

from ImageHandler import ImageHandler

class PILImageRotation(ImageHandler):
    """description of class"""

    def __init__(self, angle, expand = 0):
        self.angle = angle
        self.expand = expand


    def __Handler__(self, image):
        if image == None:
            return False, None

        if not self.__IsPILImage__(image):
            return False, image

        return True, image.rotate(self.angle, expand = self.expand, resample = Image.BICUBIC)
