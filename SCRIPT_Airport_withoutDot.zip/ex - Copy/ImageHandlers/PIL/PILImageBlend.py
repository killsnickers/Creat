from PIL import ImageFilter

from ImageHandler import ImageHandler

class PILImageBlend(ImageHandler):
    """description of class"""

    def __init__(self, offset, blendimage):
        self.offset = offset
        self.blendimage = blendimage


    def __Handler__(self, image):
        if image == None or self.blendimage == None: 
            return False, image

        if not self.__IsPILImage__(image) or not self.__IsPILImage__(self.blendimage):
            return False, image

        if image.mode != self.blendimage.mode:
            image = image.convert(mode = self.blendimage.mode)

        if image.mode == 'RGBA':
            image.paste(self.blendimage, box=(self.offset[0], self.offset[1], self.offset[0] + self.blendimage.width, self.offset[1] + self.blendimage.height), mask = self.blendimage.getchannel('A'))
        else:
            image.paste(self.blendimage, box=(self.offset[0], self.offset[1], self.offset[0] + self.blendimage.width, self.offset[1] + self.blendimage.height))

        return True, image
