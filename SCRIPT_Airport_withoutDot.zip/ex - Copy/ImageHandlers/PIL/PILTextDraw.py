from PIL import Image
from PIL import ImageFont
from PIL import ImageDraw
import random

from ImageHandler import ImageHandler


class PILTextDraw(ImageHandler):
    """description of class"""

    def __init__(self, fontname, fontsize, text, color = (0, 0, 0, 255), offset = (0, 0), rotation = (0, 0), crop = False):
        self.fontname = fontname
        self.fontsize = int(fontsize)
        self.text = text
        self.color = color
        self.offset = (int(offset[0]), int(offset[1]))
        self.rotation = rotation
        self.crop = crop


    def __Handler__(self, image):
        if image == None: 
            return False, image

        if not self.__IsPILImage__(image):
            return False, image

        if image.mode == 'RGB':
            image = image.convert(mode = 'RGBA')

        if len(self.text) == 0:
            return False, image
        
        textimage = Image.new('RGBA', (self.fontsize * len(self.text), int(self.fontsize*1.2)), color=(0, 0, 0, 0))
        if textimage.width > image.width or textimage.height > image.height:
            return False, image

        font = ImageFont.truetype(self.fontname, self.fontsize, encoding='unic')

        draw = ImageDraw.Draw(textimage)
        draw.text((0, 0), self.text, self.color, font)
        textimage = textimage.rotate(random.uniform(self.rotation[0], self.rotation[1]), resample = Image.BICUBIC, expand = 1)
        image.paste(textimage, box=(self.offset[0], self.offset[1], self.offset[0] + textimage.width, self.offset[1] + textimage.height), mask = textimage.getchannel('A'))

        if self.crop:
            image = image.crop((0, 0, min(textimage.width+self.fontsize, image.width), min(textimage.height+self.fontsize, image.height)))

        return True, image
