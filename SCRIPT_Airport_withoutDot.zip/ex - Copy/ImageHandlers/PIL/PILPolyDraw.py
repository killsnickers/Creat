from PIL import Image
from PIL import ImageDraw
import random

from ImageHandler import ImageHandler


class PILPolyDraw(ImageHandler):
    """description of class"""

    def __init__(self, fill = (0, 0, 0, 200)):
        self.fill = fill


    def __Handler__(self, image):
        if image == None:
            return False, None

        if not self.__IsPILImage__(image):
            return False, image

        poly = []
        if (int(random.uniform(0, 2))):
            poly = [(0, 0), (imageResult.width, 0), (imageResult.width, int(random.uniform(0, imageResult.height * 0.25) + imageResult.height * 0.25)), (0, int(random.uniform(0, imageResult.height * 0.5)))]
        else:
            poly = [(0, imageResult.height), (imageResult.width, imageResult.height), (imageResult.width, int(random.uniform(0, imageResult.height * 0.25) + imageResult.height * 0.5)), (0, int(random.uniform(0, imageResult.height * 0.25) + imageResult.height * 0.75))]

        draw.polygon(poly, fill = self.fill)

        return True, image