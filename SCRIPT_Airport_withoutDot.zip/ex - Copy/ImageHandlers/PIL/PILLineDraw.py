from PIL import Image
from PIL import ImageDraw
import random

from ImageHandler import ImageHandler


class PILLineDraw(ImageHandler):
    """description of class"""
    def __init__(self, fill = (156, 133, 117), width = 4):
        self.color = color
        self.width = width


    def __Handler__(self, image):
        if image == None:
            return False, None

        if not self.__IsPILImage__(image):
            return False, image

        start = [int(random.uniform(0, image.width * 0.5)), int(random.uniform(0, image.height * 0.5))]
        if (int(random.uniform(0, 2))):
            start[0] = 0
        else:
            start[1] = 0

        end = [int(random.uniform(0, imageResult.width * 0.5) + imageResult.width * 0.5), int(random.uniform(0, imageResult.height * 0.5) + imageResult.height * 0.5)]
        if (int(random.uniform(0, 2))):
            end[0] = imageResult.size[0]
        else:
            end[1] = imageResult.size[1]

        draw = ImageDraw.Draw(image)
        draw.line([tuple(start), tuple(end)], fill=self.fill, width = self.width)

        return True, image
