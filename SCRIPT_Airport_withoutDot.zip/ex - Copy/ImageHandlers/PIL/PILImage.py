import os
from PIL import Image
from PIL import ImageShow

from ImageHandler import ImageHandler


class PILImageRead(object):
    """description of class"""

    @staticmethod
    def Handler(filename):
        if filename == None or not os.path.exists(filename):
            return None

        return Image.open(filename)


class PILImageWrite(ImageHandler):
    """description of class"""
    def __init__(self, filename):
        self.filename = filename


    def __Handler__(self, image):
        if image == None or not self.__IsPILImage__(image) or self.filename == None:
            return False, image

        if image.mode != 'RGB':
            image = image.convert('RGB')

        image.save(self.filename)
        return True, image


class PILImageShow(ImageHandler):
    """description of class"""

    def __Handler__(self, image):
        if image == None or not self.__IsPILImage__(image):
            return False, image

        ImageShow.show(image)
        return True, image