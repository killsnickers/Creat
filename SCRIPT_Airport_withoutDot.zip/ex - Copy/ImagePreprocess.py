#!/usr/bin/env python2
# -*- coding:utf-8 -*-

import random
from decimal import Decimal
import json
import os,shutil
import codecs
import sys
import base64
import time
import traceback
import cv2

from ImageHoney import ImageHoney
from ImageHandlers.PIL.PILImage import PILImageRead
from ImageHandlers.PIL.PILImage import PILImageWrite
from ImageHandlers.PIL.PILImage import PILImageShow
from ImageHandlers.PIL.PILTextDraw import PILTextDraw
from ImageHandlers.PIL.DotMatrixDraw import PILDotMatrixDraw
from ImageHandlers.PIL.PILImageBlur import PILImageBlur
from ImageHandlers.PIL.PILImageBlend import PILImageBlend
from ImageHandlers.PIL.PILImageRotation import PILImageRotation

from ImageHandlers.CV2.Cv2Image import Cv2ImageRead
from ImageHandlers.CV2.Cv2Image import Cv2ImageShow
from ImageHandlers.CV2.Cv2Image import Cv2ImageWrite
from ImageHandlers.CV2.Cv2FindSplitline import Cv2FindSplitline

print (sys.argv)

args = sys.argv[1]
args = args.split(';')
targetSource = args[2].split('|')
targetSourceId = targetSource[0]
targetSourcePath = targetSource[1]
source_id=targetSourceId

if not targetSourcePath.endswith('/'):
    targetSourcePath = targetSourcePath + '/'

paramter = base64.decodestring(sys.argv[2])
paramter = json.loads(paramter)

output_path = sys.argv[3].split('|')[1]

if not output_path.endswith('/'):
    output_path = output_path + '/'

suboutputpath = 'train'
if paramter.get('suboutputpath'):
    suboutputpath = paramter.get('suboutputpath')
output_path = os.path.join(output_path, "export", suboutputpath)

if not os.path.exists(output_path):
    os.makedirs(output_path)

bgimages = []
result = ''
namespath = ''
font = ''
china_lastname_x1 = ''
china_lastname_x2 = ''
china_name = ''
mat_font_asc = ''
mat_font_hzk = ''
for root,_,files in os.walk(targetSourcePath):
    for file in files:
        if file.endswith('.png') or file.endswith('.jpg'):
            bgimages.append(os.path.join(root, file))
        elif file.endswith('.last1'):
            china_lastname_x1 = os.path.join(root, file)
        elif file.endswith('.last2'):
            china_lastname_x2 = os.path.join(root, file)
        elif file.endswith('.asc16'):
            mat_font_asc = os.path.join(root, file)
        elif file.endswith('.hzk16'):
            mat_font_hzk = os.path.join(root, file)
        elif file.endswith('.name'):
            china_name = os.path.join(root, file)
        elif file.endswith('.json'):
            result = os.path.join(root, file)
        elif file.endswith('.txt'):
            namespath = os.path.join(root, file)
        elif file.endswith('ttf') or file.endswith('ttc'):
            font = os.path.join(root, file)

rotation = 5
if paramter.get('rotation'):
    rotation = int(paramter.get('rotation'))

def GenerateSaleName():
    global result
    print('Start GenerateSaleName')

    result = json.load(open(result))
    names = []
    for name in codecs.open(namespath, encoding='utf-8').read().split('\n'):
        name = name.split(' ')[0]
        if len(name) > 4:
            names.append(name)

    count = 10000
    if paramter.get('count'):
        count = int(paramter.get('count'))

    for index in range(0, count):
        name = names[int(random.uniform(0, len(names)))] + names[int(random.uniform(0, len(names)))]
        bgimage = PILImageRead.Handler(bgimages[int(random.uniform(0, len(bgimages)))])
        honey = ImageHoney(bgimage)
        ImageHandlerList = [PILTextDraw(font, bgimage.width / (len(name) + 2), text = name, color = (0, 0, 0, 160), crop = True, rotation = (-rotation, rotation)), PILImageBlur(radius = (0, 1)), PILImageWrite(os.path.join(output_path, str(index) + '.jpg'))]
        if honey.Honey(ImageHandlerList):
            result[0]['result'][0] = name
            result[0]['region'][2] = honey.image.width
            result[0]['region'][3] = honey.image.height
            if paramter.get('cls'):
                result[0]['cls'] = paramter.get('cls')
            open(os.path.join(output_path, str(index) + '.txt'), 'w').write(json.dumps(result))

    print('End GenerateSaleName')


def GenerateCreditInfomation():
    global result
    print('Start GenerateCreditInfomation')

    creditInfomation = ('1', '2', '3', '4', '5', '6', '7', '/', '*', 'N', 'D', 'Z', 'C', 'G', '#')
    count = 10000
    if paramter.get('count'):
        count = int(paramter.get('count'))

    result = json.load(open(result))
    for index in range(0, count):
        bgimage = PILImageRead.Handler(bgimages[int(random.uniform(0, len(bgimages)))])
        name = ''
        for charIndex in range(0, 24):
            char = creditInfomation[int(random.uniform(0, len(creditInfomation)))]
            name += char
            honey = ImageHoney(bgimage)
            ImageHandlerList = [PILTextDraw(font, 20, text = char, color = (0, 0, 0, 160), offset = (13 + charIndex * 32, 8))]
            honey.Honey(ImageHandlerList)
        ImageHandlerList = [PILImageBlur(radius = (random.uniform(0, 2), random.uniform(0, 2))), PILImageWrite(os.path.join(output_path, str(index) + '.jpg'))]
        if honey.Honey(ImageHandlerList):
            result[0]['result'][0] = name
            result[0]['region'][2] = honey.image.width
            result[0]['region'][3] = honey.image.height
            if paramter.get('cls'):
                result[0]['cls'] = paramter.get('cls')
            open(os.path.join(output_path, str(index) + '.txt'), 'w').write(json.dumps(result))


    print('End GenerateSaleName')


def GenerateAmount():
    global result
    print('Start GenerateAmount')

    charlist = (u'壹', u'贰', u'叁', u'肆', u'伍', u'陆', u'柒', u'捌', u'玖', u'拾', u'佰', u'仟', u'万', u'整', u'亿', u'元', u'角', u'分', u'零', u'正')
    count = 10000
    if paramter.get('count'):
        count = int(paramter.get('count'))

    result = json.load(open(result))
    for index in range(0, count):
        bgimage = PILImageRead.Handler(bgimages[int(random.uniform(0, len(bgimages)))])
        honey = ImageHoney(bgimage)
        name = charlist[int(random.uniform(0, len(charlist)))] + ' ' + charlist[int(random.uniform(0, len(charlist)))] + ' ' + charlist[int(random.uniform(0, len(charlist)))]
        fontsize = bgimage.height / 5 * 3
        ImageHandlerList = [PILTextDraw(font, bgimage.height / 5 * 3, text = name, color = (0, 0, 0, 160), offset = (fontsize * 0.5, fontsize * 0.25)), PILImageBlur(radius = (random.uniform(0, 3), random.uniform(0, 3))), PILImageWrite(os.path.join(output_path, str(index) + '.jpg'))]
        if honey.Honey(ImageHandlerList):
            result[0]['result'][0] = name
            result[0]['region'][2] = honey.image.width
            result[0]['region'][3] = honey.image.height
            if paramter.get('cls'):
                result[0]['cls'] = paramter.get('cls')
            open(os.path.join(output_path, str(index) + '.txt'), 'w').write(json.dumps(result))


def ImagePreprocess(image):
    handler = Cv2FindSplitline();
    flag, images = handler.__Handler__(image)
    return images


def GenerateName():
    global result
    print('Start GenerateName')

    lastnames = []
    for lastname in codecs.open(china_lastname_x1, encoding='utf-8').read():
        if len(lastname) == 1:
            lastnames.append(lastname)

    for lastname in codecs.open(china_lastname_x2, encoding='utf-8').read().split('\n'):
        lastname = lastname.strip()
        if len(lastname) == 2:
            lastnames.append(lastname)

    names = []
    for name in codecs.open(china_name, encoding='utf-8').read():
        if len(name) == 1:
            names.append(name)

    count = 10000
    if paramter.get('count'):
        count = int(paramter.get('count'))

    result = json.load(open(result))
    for index in range(0, count):
        bgimage = PILImageRead.Handler(bgimages[int(random.uniform(0, len(bgimages)))])
        honey = ImageHoney(bgimage)
        name = lastnames[int(random.uniform(0, len(lastnames)))]
        name += names[int(random.uniform(0, len(names)))]
        if int(random.uniform(0, 100)) > 50:
            name += names[int(random.uniform(0, len(names)))]
        fontsize = bgimage.height / 5 * 3
        ImageHandlerList = [PILTextDraw(font, bgimage.height / 5 * 3, text=name, color=(0, 0, 0, 160), offset=(fontsize * 0.5, fontsize * 0.25)),
                            PILImageBlur(radius=(random.uniform(0, 3), random.uniform(0, 3))),
                            PILImageWrite(os.path.join(output_path, str(index) + '.jpg'))]
        if honey.Honey(ImageHandlerList):
            result[0]['result'][0] = name
            result[0]['region'][2] = honey.image.width
            result[0]['region'][3] = honey.image.height
            if paramter.get('cls'):
                result[0]['cls'] = paramter.get('cls')
            open(os.path.join(output_path, str(index) + '.txt'), 'w').write(json.dumps(result))

def GenerateAirport():
    global result
    print('Start GenerateDotMatrixName')
    random_list = [2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 5, 6]
    names = []
    for i in range(25):
        for name in codecs.open(namespath, encoding='utf-8').read():
            name = name.strip()
            try:
                gb2312str = name.encode('gb2312')
                if len(name) == 1:
                    names.append(name)
            except:
                pass

    for j in range(len(names)):
        randomnum = random.randint(0, len(names) - 1)
        temp = names[j]
        names[j] = names[randomnum]
        names[randomnum] = temp

    start_name_num = 0
    airport_name_list = []
    max_airport_name_length = 7
    while start_name_num < len(names) - max_airport_name_length:
        randomlist = random.sample(random_list, 1)
        random_num = randomlist[0]
        if random_num == 2:
            airport_name = names[start_name_num + 1] + names[start_name_num + 2]
            start_name_num = start_name_num + 2
            airport_name_list.append(airport_name)
        elif random_num == 3:
            airport_name = names[start_name_num + 1] + names[start_name_num + 2] + names[start_name_num + 3]
            start_name_num = start_name_num + 3
            airport_name_list.append(airport_name)
        elif random_num == 4:
            airport_name = names[start_name_num + 1] + names[start_name_num + 2] + names[start_name_num + 3] + names[
                start_name_num + 4]
            start_name_num = start_name_num + 4
            airport_name_list.append(airport_name)
        elif random_num == 5:
            airport_name = names[start_name_num + 1] + names[start_name_num + 2] + names[start_name_num + 3] + names[
                start_name_num + 4] + names[start_name_num + 5]
            start_name_num = start_name_num + 5
            airport_name_list.append(airport_name)
        elif random_num == 6:
            airport_name = names[start_name_num + 1] + names[start_name_num + 2] + names[start_name_num + 3] + names[
                start_name_num + 4] + names[start_name_num + 5] + names[start_name_num + 6]
            start_name_num = start_name_num + 6
            airport_name_list.append(airport_name)
        else:
            continue

    count = 2800
    if paramter.get('count'):
        count = int(paramter.get('count'))
    count  = len(airport_name_list)
    asc_array = None
    hzk_array = None
    with open(mat_font_hzk, 'rb') as f:
        hzk_array = bytearray(f.read())
    result = json.load(open(result))
    for index in range(0, count):
        firstname = airport_name_list[index]
        name = firstname[0]
        for i in range(len(firstname) - 1):
            if i == 0:
                continue
            ch = firstname[i]
            name = name + u'  ' + ch
        name = name + u'  ' + firstname[len(firstname) - 1]
        bgimage = PILImageRead.Handler(bgimages[int(random.uniform(0, len(bgimages)))])
        while bgimage.height < 28 or bgimage.width < 160:
            bgimage = PILImageRead.Handler(bgimages[int(random.uniform(0, len(bgimages)))])

        honey = ImageHoney(bgimage)
        fontsize = bgimage.height * 0.6
        fitlength = bgimage.width * 0.9 / fontsize

        blur_ = 1
        if bgimage.height > 80:
            blur_ = 3
        if bgimage.height > 55:
            blur_ = 2
        if 21 < bgimage.height < 26:
            blur_ = 1

        large = int(bgimage.height /2)


        ImageHandlerList = [
            PILTextDraw(font, large, text=name, color=(0, 0, 0, 255),
                        offset=(fontsize * 0.5, fontsize * 0.25), crop=True),
            PILImageBlur(radius=(blur_, blur_+0.2)),
            PILImageWrite(os.path.join(output_path, str(index) + '.jpg'))
            ]

        if honey.Honey(ImageHandlerList):
            result[0]['result'][0] = name
            result[0]['region'][2] = honey.image.width
            result[0]['region'][3] = honey.image.height
            if paramter.get('cls'):
                result[0]['cls'] = paramter.get('cls')
            open(os.path.join(output_path, str(index) + '.txt'), 'w').write(
                json.dumps(result))
        if index%100 == 0:
            print index



def GenerateDotMatrixName():
    global result
    print('Start GenerateDotMatrixName')

    lastnames = []
    for lastname in codecs.open(china_lastname_x1, encoding='utf-8').read():
        if len(lastname) == 1:
            lastnames.append(lastname)

    for lastname in codecs.open(china_lastname_x2, encoding='utf-8').read().split('\n'):
        lastname = lastname.strip()
        if len(lastname) == 2:
            lastnames.append(lastname)

    names = []
    for name in codecs.open(china_name, encoding='utf-8').read():
        if len(name) == 1:
            names.append(name)

    count = 10000
    if paramter.get('count'):
        count = int(paramter.get('count'))

    asc_array = None
    hzk_array = None
    with open(mat_font_hzk, 'rb') as f:
        hzk_array = bytearray(f.read())
    result = json.load(open(result))
    for index in range(0, count):
        bgimage = PILImageRead.Handler(bgimages[int(random.uniform(0, len(bgimages)))])
        honey = ImageHoney(bgimage)
        fontsize = bgimage.height * 0.85
        fitlength = bgimage.width * 0.9 / fontsize
        name = lastnames[int(random.uniform(0, len(lastnames)))]
        name += names[int(random.uniform(0, len(names)))]
        if int(random.uniform(0, 100)) > 70:
            name += names[int(random.uniform(0, len(names)))]

        ImageHandlerList = [
            PILDotMatrixDraw(asc_array, hzk_array, fontsize, text=name, color=(0, 0, 0, 255), offset=(fontsize * 0.5, fontsize * 0.15)),
            PILImageBlur(radius=(random.uniform(0, 3), random.uniform(0, 1.5))),
            PILImageWrite(os.path.join(output_path, str(index) + '.jpg'))
        ]

        if honey.Honey(ImageHandlerList):
            result[0]['result'][0] = name
            result[0]['region'][2] = honey.image.width
            result[0]['region'][3] = honey.image.height
            if paramter.get('cls'):
                result[0]['cls'] = paramter.get('cls')
            open(os.path.join(output_path, str(index) + '.txt'), 'w').write(json.dumps(result))
        if index % 100 == 0:
            print str(index)


def GenerateDotMatrixAirport():
    global result
    print('Start GenerateDotMatrixName')
    random_list = [2, 2, 2, 2, 2, 2, 3, 3, 3, 4, 5, 6]
    names = []
    for i in range(25):
        for name in codecs.open(namespath, encoding='utf-8').read():
            name = name.strip()
            try:
                gb2312str = name.encode('gb2312')
                if len(name) == 1:
                    names.append(name)
            except:
                pass

    for j in range(len(names)):
        randomnum = random.randint(0, len(names) - 1)
        temp = names[j]
        names[j] = names[randomnum]
        names[randomnum] = temp


    start_name_num = 0
    airport_name_list = []
    max_airport_name_length = 7
    while start_name_num < len(names)-max_airport_name_length:
        randomlist = random.sample(random_list, 1)
        random_num = randomlist[0]
        if random_num == 2:
            airport_name = names[start_name_num+1] + names[start_name_num + 2]
            start_name_num = start_name_num + 2
            airport_name_list.append(airport_name)
        elif random_num == 3:
            airport_name = names[start_name_num + 1] + names[start_name_num + 2]+names[start_name_num + 3]
            start_name_num = start_name_num + 3
            airport_name_list.append(airport_name)
        elif random_num == 4:
            airport_name = names[start_name_num + 1] + names[start_name_num + 2]+names[start_name_num + 3]+names[start_name_num + 4]
            start_name_num = start_name_num + 4
            airport_name_list.append(airport_name)
        elif random_num == 5:
            airport_name = names[start_name_num + 1] + names[start_name_num + 2]+names[start_name_num + 3]+names[start_name_num + 4]+names[start_name_num + 5]
            start_name_num = start_name_num + 5
            airport_name_list.append(airport_name)
        elif random_num == 6:
            airport_name = names[start_name_num + 1] + names[start_name_num + 2] + names[start_name_num + 3] + names[start_name_num + 4] + names[start_name_num + 5]+ names[start_name_num + 6]
            start_name_num = start_name_num + 6
            airport_name_list.append(airport_name)
        else:
            continue

    count = 2800
    if paramter.get('count'):
        count = int(paramter.get('count'))

    asc_array = None
    hzk_array = None
    with open(mat_font_hzk, 'rb') as f:
        hzk_array = bytearray(f.read())
    result = json.load(open(result))
    for index in range(0, count):
        repetitions = 0
        name = airport_name_list[index]
        bgimage = PILImageRead.Handler(bgimages[int(random.uniform(0, len(bgimages)))])
        while bgimage.height < 40 or bgimage.width < 160:
            bgimage = PILImageRead.Handler(bgimages[int(random.uniform(0, len(bgimages)))])

        honey = ImageHoney(bgimage)
        fontsize = bgimage.height * 0.7
        fitlength = bgimage.width * 0.9 / fontsize

        blur_ = random.randint(0, 1)
        if bgimage.height > 60:
            blur_ = 1

        if 21 < bgimage.height < 26:
            blur_ = 3
    
        ImageHandlerList = [
            PILDotMatrixDraw(asc_array, hzk_array, fontsize, text=name, color=(0, 0, 0, 255), offset=(fontsize * 0.5, fontsize * 0.05), crop=True),
            PILImageBlur(radius=(blur_, blur_ + 0.2)),
            PILImageWrite(os.path.join(output_path, str(index) + '_' + str(repetitions) + '.jpg'))
        ]
    
        if honey.Honey(ImageHandlerList):
            result[0]['result'][0] = name
            result[0]['region'][2] = honey.image.width
            result[0]['region'][3] = honey.image.height
            if paramter.get('cls'):
                result[0]['cls'] = paramter.get('cls')
            open(os.path.join(output_path, str(index) + '_' + str(repetitions) + '.txt'), 'w').write(json.dumps(result))
        if index%100 == 0:
            print index
if __name__ == '__main__':
    #GenerateDotMatrixAirport()
    GenerateAirport()

