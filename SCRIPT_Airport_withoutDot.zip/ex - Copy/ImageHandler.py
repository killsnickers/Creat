import cv2
from PIL import Image
import numpy
from enum import Enum


class ImageHandler(object):
    """description of class"""

    def __init__(self):
        pass

    
    def __Handler__(self, image):
        return False, None


    def __IsPILImage__(self, image):
        return Image.isImageType(image)


    def __IsCv2Image__(self, image):
        return not self.__IsPILImage__(image)


    def __cv2ToPIL__(self, image):
        if image == None or not isinstance(image, numpy.ndarray):
            return None;

        if image.shape[2] == 3:
            return Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGR2RGB))
        elif image.shape[2] == 4:
            return Image.fromarray(cv2.cvtColor(image, cv2.COLOR_BGRA2RGBA))
        
        return None


    def __PILTocv2__(self, image):
        if image == None or not Image.isImageType(image):
            return None

        if image.mode == 'RGB':
            return cv2.cvtColor(numpy.asarray(image), cv2.COLOR_RGB2BGR)
        elif image.mode == 'RGBA':
            return cv2.cvtColor(numpy.asarray(image), cv2.COLOR_RGBA2BGRA)
        
        return None
