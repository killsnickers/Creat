class ImageHoney(object):
    """description of class"""

    def __init__(self, image):
        self.image = image


    def Honey(self, handlerList):
        for handler in handlerList:
            flag, self.image = handler.__Handler__(self.image)
            if not flag:
                return False
        return True


