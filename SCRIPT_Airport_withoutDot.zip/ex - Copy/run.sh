#!/bin/bash 
pip install Pillow==5.1.0

line=$2
arr=(${line//;/ })  
arr2=${arr[0]}
mainsource=(${arr2//:/ })
cd ${mainsource[1]}
python ImagePreprocess.py $2 $4 $6 $8