# -*- coding: utf-8 -*-

import logging
import re
import Domestic.VATRoll.CompanyList as CompanyList
from utils import StrUtil
from DataFixed import DataFixed
from ConfidenceLevel import ConfidenceLevel


class BuyerNameFixed(DataFixed):
    """description of class"""

    def __init__(self):
        DataFixed.__init__(self, 'BuyerName')
        # self.__Threshold__ = 0.85

    def __FixedData__(self, resultJson):
        buyer_names = self.__ParseData__(resultJson)
        if len(buyer_names) == 0:
            logging.info(u'Buyer Name Error')
            return ConfidenceLevel.Bad, ''

        logging.info(buyer_names[0] + u' Fixed To ')

        buyer_names = self.__ReplaceSpecialChar__(buyer_names)
        buyer_names = self.__ReplaceSonCompany__(buyer_names)
        confidencelevel, name = self.__FixBuyerName__(buyer_names)

        logging.info(name)
        #logging.info(confidencelevel)
        return confidencelevel, name

    def __FixedDataWithValidate__(self, resultJson, validateJson):
        buyer_names = self.__ParseData__(resultJson)
        validated_buyer_names = self.__ParseData__(validateJson)

        if len(validated_buyer_names) == 0 or len(buyer_names) == 0 or not self.__CheckData__(
                validated_buyer_names[0]):
            logging.info(u'Validated Data Error')
            return

        if validated_buyer_names[0] != buyer_names[0]:
            self.__ErrorCount__ += 1
        else:
            logging.info(u'Validated Equal To Result')
            return

        logging.info(u'Validated Not Equal To Result')
        logging.info(buyer_names[0] + u' Fixed To ')

        confidencelevel, name = self.__FixBuyerName__(buyer_names)

        logging.info(name)
        logging.info(confidencelevel)

        if validated_buyer_names[0] == name:
            self.__FixedCount__ += 1
            logging.info(u'Fixed Success!')
        else:
            logging.info(u'Validated ' + validated_buyer_names[0])
            logging.info(u'Fixed Falied!')

    def __ParseData__(self, jsondata):
        buyer_names = []

        if jsondata == None or not isinstance(jsondata, dict) or jsondata[u'regions'] == None:
            return buyer_names

        regions = jsondata[u'regions']
        regions = sorted(regions, key=lambda region: region[u'confidence'], reverse=True)

        for region in regions:
            if region[u'cls'] == None or region[u'result'] == None or region[u'ref_result'] == None:
                continue

            cls = region[u'cls']
            if cls == 45:
                for result in region[u'result']:
                    if len(result):
                        buyer_names.append(result)

                for result in region[u'ref_result']:
                    if len(result):
                        buyer_names.append(result)

        return buyer_names

    def __CheckData__(self, data):
        return True

    def __FixBuyerName__(self, buyer_names):
        for buyer_name in buyer_names:
            if buyer_name in CompanyList.CompanyList:
                return ConfidenceLevel.Confident, buyer_name

        return ConfidenceLevel.Bad, buyer_names[0]

    def __ReplaceSpecialChar__(self, seller_names):
        replaced_names = []
        for index in range(len(seller_names)):
            name = re.sub(r'\\|n', u'', seller_names[index])
            name = re.sub(u'[a-z]|[A-Z]|[0-9]', u'', name)
            replaced_names.append(name)

        return replaced_names

    def __ReplaceSonCompany__(self, seller_names):
        replaced_names = []
        for index in range(len(seller_names)):
            name = re.sub(u'公+司+', u'公司', seller_names[index])
            name = re.sub(u'分+公*司+|分+司|分+公+', u'分公司', name)
            name = re.sub(u'亮牌', u'壳牌', name)
            name = re.sub(u'[a-z]|[A-Z]|[0-9]', u'', name)
            replaced_names.append(name)

        return replaced_names
