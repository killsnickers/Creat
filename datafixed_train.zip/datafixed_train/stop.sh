kill `cat gunicorn.pid`
