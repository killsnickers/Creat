from enum import Enum

class ClsType(Enum):
    EntryStation = 15
    ExitStation = 16
    Name = 23
    AmountInWords = 29
