from enum import Enum

class ConfidenceLevel(Enum):
    Confident = 'Confident'
    Fixed = 'Fixed'
    Bad = 'Bad'
