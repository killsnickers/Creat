#!/usr/bin/env python2
# -*- coding:utf-8 -*-

import logging

import Domestic.IntercityCar.CarStationList as CarStationList
from DataFixed import DataFixed
from ConfidenceLevel import ConfidenceLevel
import re
from utils import StrUtil


class StartStationFixed(DataFixed):
    def __init__(self):
        DataFixed.__init__(self, 'StartStation')

    def __FixedData__(self, resultJson):
        startstationlist = self.__ParseData__(resultJson)
        if len(startstationlist) == 0:# or len(endstationlist) == 0:
            logging.info(u'Station Data Error')
            return ConfidenceLevel.Bad, ''

        logging.info(startstationlist[0] + u' Fixed To ')
        confidencelevel, start_station_result = self.__FixedStationData__(startstationlist)
        logging.info(start_station_result)

        return confidencelevel, start_station_result



    def __ParseData__(self, jsondata):
        startstationlist = []
        #endstationlist = []

        if jsondata == None or not isinstance(jsondata, dict) or jsondata[u'regions'] == None:
            return startstationlist

        regions = jsondata[u'regions']

        for region in regions:
            if region[u'cls'] == None or region[u'result'] == None or region[u'ref_result'] == None:
                continue

            cls = region[u'cls']
            if cls == 15:
                for result in region[u'result']:
                    if len(result):
                        startstationlist.append(result)

                if region.get(u'ref_result') != None:
                    for result in region[u'ref_result']:
                        if len(result):
                            startstationlist.append(result)

        return startstationlist

    def __FixedStationData__(self, datalist):

        if len(datalist) == 0:
            return ConfidenceLevel.Bad, ''

        resultlist = self.__ReplaceSpecialChar__(datalist)

        for result in resultlist:
            if result in CarStationList.Carstationlist:
                return ConfidenceLevel.Confident, result

        return ConfidenceLevel.Fixed, resultlist[0]


    def __ReplaceSpecialChar__(self, datalist):
        replaced_stations = []

        for index in range(len(datalist)):
            name = re.sub(r'\\|n', u'', datalist[index])
            name = re.sub(u'[a-z]|[A-Z]|[0-9]', u'', name)
            replaced_stations.append(name)

        return replaced_stations
