# -*- encoding: utf-8 -*-

import re
import logging

from ConfidenceLevel import ConfidenceLevel
from DataFixed import DataFixed
from ClsType import ClsType

class NameFixed(DataFixed):
    def __init__(self):
        DataFixed.__init__(self, u'Station')
        self.cls = ClsType.Name.value

    def __ParseData__(self, jsondata):
        names = []

        if jsondata == None or not isinstance(jsondata, dict) or jsondata[u'regions'] == None:
            return names

        regions = jsondata[u'regions']

        for region in regions:
            if region[u'cls'] == None or region[u'result'] == None:
                continue

            cls = region[u'cls']
            if cls == self.cls:
                for result in region[u'result']:
                    if len(result):
                        names.append(result)

                if region.get(u'ref_result') != None:
                    for result in region[u'ref_result']:
                        if len(result):
                            names.append(result)

        return names

    def __FixedData__(self, resultJson):
        names = self.__ParseData__(resultJson)

        if not len(names):
            logging.info('name error')
            return ConfidenceLevel.Bad, ''

        logging.info(names[0] + ' fixed to')
        confidence_level, names = self.fixname(names)

        logging.info(names)
        return confidence_level, names


    def fixname(self, names):
        station = re.sub(r'[A-Z0-9]', u'', names[0])
        return ConfidenceLevel.Bad, station