# -*- coding: utf-8 -*-
import logging
import re

from DataFixed import DataFixed
from ConfidenceLevel import ConfidenceLevel
from NameToCategory import NameToCategory


class ReceiptCategoryFix(DataFixed):
    """description of class"""

    def __init__(self):
        DataFixed.__init__(self, 'Category')


    def __FixedData__(self, resultJson):
        objectName = self.__ParseData__(resultJson)

        if objectName is None:
            logging.info(u'Parse Object Name Error')
            return ConfidenceLevel.Bad, ''

        logging.info(objectName + u' Fixed To ')
        confidenceLevel, categoryName = self.__FixCategory__(objectName)
        logging.info(categoryName)

        return confidenceLevel, categoryName


    def __ParseData__(self, jsondata):
        objectNames = []
        if jsondata is None or not isinstance(jsondata, dict) or jsondata[u'regions'] is None:
            return None

        regions = jsondata[u'regions']

        for region in regions:
            if region[u'cls'] is None or region[u'result'] is None:
                continue

            cls = region[u'cls']
            if cls == 20:
                objectNames.append(region)

        if len(objectNames):
            objectNames.sort(key=lambda region: region[u'region'][1])
            return objectNames[0][u'result'][0]
        return None

    def __FixCategory__(self, objectName):
        return ConfidenceLevel.Bad, NameToCategory(objectName)
