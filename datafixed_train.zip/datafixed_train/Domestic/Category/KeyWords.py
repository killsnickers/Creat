# -*- coding: utf-8 -*-

from ReceiptCategory import *
from enum import Enum
import os.path


class CompareType(Enum):
    Contain = u'CT_Contain',
    Prefix = u'CT_Prefix',
    Suffix = u'CT_Suffix',


class KeyWords(object):
    CommonKeyWords = None

    KeyWordTypeName = {
        ReceiptCategory.Dining: u'餐饮',
        ReceiptCategory.Food: u'食品',
        ReceiptCategory.AutoTransport: u'交通',
        ReceiptCategory.Lodging: u'住宿',
        ReceiptCategory.Decoration: u'房租装修',
        ReceiptCategory.VehicleMaintain: u'用车',
        ReceiptCategory.Communication: u'通讯',
        ReceiptCategory.Mailing: u'邮寄',
        ReceiptCategory.ElectricEquipment: u'电器',
        ReceiptCategory.UtilityFee: u'水电',
        ReceiptCategory.Service: u'服务',
        ReceiptCategory.Apparel: u'服饰',
        ReceiptCategory.Education: u'教育',
        ReceiptCategory.Medical: u'医疗',
        ReceiptCategory.Other: u'其他',
        ReceiptCategory.OfficeConsumables: u'办公易耗',
        ReceiptCategory.DailyNecessities: u'生活日用',
        ReceiptCategory.DigitalEquipment: u'电子产品',
    }

    @staticmethod
    def Load():
        if KeyWords.CommonKeyWords:
            return

        KeyWords.CommonKeyWords = {
            ReceiptCategory.Dining: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.Food: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.AutoTransport: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.Lodging: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.Decoration: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.VehicleMaintain: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.Communication: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.Mailing: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.DailyNecessities: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.DigitalEquipment: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.UtilityFee: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.Service: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.Apparel: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.Education: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.Medical: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.ElectricEquipment: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
            ReceiptCategory.OfficeConsumables: {
                CompareType.Contain: [],
                CompareType.Prefix: [],
                CompareType.Suffix: [],
            },
        }

        dir_path = os.path.dirname(os.path.realpath(__file__))
        path = os.path.join(dir_path, 'keywords')
        for tp, keywordsMap in KeyWords.CommonKeyWords.items():
            filename = str(tp) + '.suffix'
            filepath = os.path.join(path, filename)
            if os.path.isfile(filepath):
                keywordsMap[CompareType.Suffix].extend(KeyWords.ReadKeyWords(filepath))
            else:
                open(filepath, 'w')
            filename = str(tp) + '.prefix'
            filepath = os.path.join(path, filename)
            if os.path.isfile(filepath):
                keywordsMap[CompareType.Prefix].extend(KeyWords.ReadKeyWords(filepath))
            else:
                open(filepath, 'w')
            filename = str(tp) + '.contain'
            filepath = os.path.join(path, filename)
            if os.path.isfile(filepath):
                keywordsMap[CompareType.Contain].extend(KeyWords.ReadKeyWords(filepath))
            else:
                open(filepath, 'w')

    @staticmethod
    def ReadKeyWords(filepath):
        with open(filepath, 'r') as f:
            kws = f.read()
            kwlist = kws.split('\n')
            result = []
            for kw in kwlist:
                w = kw.strip()
                if len(w):
                    w = w.decode('utf-8')
                    if not w.startswith('###'):
                        w = w.upper()
                        result.append(w)
            return result
        return []
