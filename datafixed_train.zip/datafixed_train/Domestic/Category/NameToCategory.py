from ReceiptCategory import ReceiptCategory
from KeyWords import *
import re


def NameToCategoryEnum(name):
    KeyWords.Load()
    chineseName = re.sub('\\\\\\\\n', '', name)
    chineseName = re.sub('[#\(\)\s]+', '', chineseName)
    chineseName = chineseName.upper()
    result = {}  # type -> likelihood
    for tp, tpMap in KeyWords.CommonKeyWords.items():
        surfixList = tpMap[CompareType.Suffix]
        for keyword in surfixList:
            if chineseName.endswith(keyword):
                result[tp] = 1.0
        prefixList = tpMap[CompareType.Prefix]
        for keyword in prefixList:
            if chineseName.startswith(keyword):
                result[tp] = 1.0
        containList = tpMap[CompareType.Contain]
        for keyword in containList:
            if keyword in chineseName:
                r = len(keyword) / float(len(chineseName))
                if tp not in result.keys():
                    result[tp] = r
                elif result[tp] < r:
                    result[tp] = r
    sortedResult = sorted(result.items(), key=lambda v: -v[1])
    if len(sortedResult):
        return sortedResult[0][0]
    return ReceiptCategory.Other


def NameToCategory(name):
    category = NameToCategoryEnum(name)
    return KeyWords.KeyWordTypeName[category]
