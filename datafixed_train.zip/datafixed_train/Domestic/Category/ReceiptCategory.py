from enum import Enum


class ReceiptCategory(Enum):
    Dining = u'RT_Dining',
    Food = u'RT_Food5',
    AutoTransport = u'RT_AutoTransport',
    Lodging = u'RT_Lodging',
    Decoration = u'RT_Decoration',
    VehicleMaintain = u'RT_VehicleMaintain',
    Communication = u'RT_Communication',
    Mailing = u'RT_Mailing',
    DailyNecessities = u'RT_DailyNecessities',
    DigitalEquipment = u'RT_DigitalEquipment',
    ElectricEquipment = u'RT_ElectricEquipment',
    OfficeConsumables = u'RT_OfficeConsumables',
    UtilityFee = u'RT_UtilityFee',
    Service = u'RT_Service',
    Apparel = u'RT_Apparel',
    Education = u'RT_Education',
    Medical = u'RT_Medical',
    Other = u'RT_Other',
