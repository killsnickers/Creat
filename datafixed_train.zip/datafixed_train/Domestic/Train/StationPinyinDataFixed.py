import logging

import Domestic.Train.StationList as StationList
import Domestic.Train.StationPinyinList as StationPinyinList
import Domestic.Train.DicPinyinStation as DicPinyinStation
from DataFixed import DataFixed
from ConfidenceLevel import ConfidenceLevel
import Levenshtein
import re
import random


class StationPinyinDataFixed(DataFixed):
    """description of class"""

    def __init__(self):
        DataFixed.__init__(self, 'StationPinyin')

    def StartFixedFromJson(self, resultJson, startStation, endStation):
        return self.__FixedData__(resultJson, startStation, endStation)


    def __FixedData__(self, resultJson, startStation, endStation):
        result_startstationlist, result_endstationlist = self.__ParseData__(resultJson)
        if len(result_startstationlist) == 0 or len(result_endstationlist) == 0:
            logging.info(u'Station Data Error')
            return ConfidenceLevel.Bad, '', ''

        logging.info(result_startstationlist[0] + ', ' + result_endstationlist[0] + u' Fixed To ')

        startconfidencelevel, startstation_pinyin = self.__FixedStationPinyinData__(result_startstationlist)
        endstationconfidencelevel, endstation_pinyin = self.__FixedStationPinyinData__(result_endstationlist)

        real_start_pinyin, real_start_station = self.__PinyinMap__(startconfidencelevel, startstation_pinyin, startStation)
        real_end_pinyin, real_end_station = self.__PinyinMap__(endstationconfidencelevel, endstation_pinyin, endStation)

        real_start_pinyin = self.__UpFirstCharacter__(real_start_pinyin)
        real_end_pinyin = self.__UpFirstCharacter__(real_end_pinyin)

        confidencelevel = ConfidenceLevel.Bad
        if startconfidencelevel == ConfidenceLevel.Bad or endstationconfidencelevel == ConfidenceLevel.Bad:
            confidencelevel = ConfidenceLevel.Bad
        elif startconfidencelevel == ConfidenceLevel.Fixed or endstationconfidencelevel == ConfidenceLevel.Fixed:
            confidencelevel = ConfidenceLevel.Fixed
        else:
            confidencelevel = ConfidenceLevel.Confident

        logging.info(real_start_pinyin + ', ' + real_end_pinyin)
        logging.info('mapping to '+real_start_station+', '+real_end_station)

        return confidencelevel, real_start_station, real_start_pinyin, real_end_station, real_end_pinyin


    def __ParseData__(self, jsondata):
        startstationpinyinlist = []
        endstationpinyinlist = []

        if jsondata == None or not isinstance(jsondata, dict) or jsondata[u'regions'] == None:
            return startstationpinyinlist, endstationpinyinlist

        regions = jsondata[u'regions']

        for region in regions:
            if region[u'cls'] == None or region[u'result'] == None or region[u'ref_result'] == None:
                continue

            cls = region[u'cls']
            if cls == 25:
                for result in region[u'result']:
                    if len(result):
                        startstationpinyinlist.append(self.__replaceComma__(result.lower()))

                if region.get(u'ref_result') != None:
                    for result in region[u'ref_result']:
                        if len(result):
                            startstationpinyinlist.append(self.__replaceComma__(result.lower()))

            elif cls == 26:
                for result in region[u'result']:
                    if len(result):
                        endstationpinyinlist.append(self.__replaceComma__(result.lower()))

                if region.get(u'ref_result') != None:
                    for result in region[u'ref_result']:
                        if len(result):
                            endstationpinyinlist.append(self.__replaceComma__(result.lower()))

        return startstationpinyinlist, endstationpinyinlist

    def __FixedStationPinyinData__(self, datalist):
        temp_station_pinyin = []
        max_diff = 1
        if not len(datalist):
            return ConfidenceLevel.Bad, ''
        for data in datalist:
            if data in StationPinyinList.StationPinyinList:
                return ConfidenceLevel.Confident, [data]
            for station_pinyin in StationPinyinList.StationPinyinList:
                diff_result = Levenshtein.distance(data, station_pinyin)
                if diff_result <= max_diff:
                    if station_pinyin not in temp_station_pinyin:
                        temp_station_pinyin.append(station_pinyin)
                        logging.info(station_pinyin)
        if len(temp_station_pinyin):
            return ConfidenceLevel.Fixed, temp_station_pinyin
        return ConfidenceLevel.Bad, [datalist[0]]

    def __PinyinMap__(self, station_confidencelevel, station_pinyin, station_name):
        if not len(station_pinyin):
            return '', station_name
        if station_confidencelevel == ConfidenceLevel.Bad:
            return station_pinyin[0], station_name
        temp_name_pinyin_dic = {}
        name_list = []
        final_name = []
        for station_pinyin_item in station_pinyin:
            result_list = DicPinyinStation.DicPinyinStation[station_pinyin_item]
            for item in result_list:
                name_list.append(item)
                temp_name_pinyin_dic[item] = station_pinyin_item
        if len(station_name) == 0:
            return temp_name_pinyin_dic[name_list[0]], name_list[0]
        if station_name not in StationList.StationList:
            return temp_name_pinyin_dic[name_list[0]], name_list[0]
        if len(name_list):
            if station_name in name_list:
                return temp_name_pinyin_dic[station_name], station_name
            for name in name_list:
                if Levenshtein.distance(station_name, name) <= 1:
                    final_name.append(name)
        if len(final_name):
            real_name = random.sample(final_name, 1)[0]
            pinyin = temp_name_pinyin_dic[real_name]
            return pinyin, real_name

        return station_pinyin[0], station_name


    def __replaceComma__(self, data):
        data =re.sub(u'\'', u'', data)
        return data


    def __UpFirstCharacter__(self, data):
        if not len(data):
            return data
        result = ''
        flag = False
        for i in range(len(data)):
            if flag:
                result += data[i]
                continue
            a = data[i].upper()
            result += a
            flag = True

        return result