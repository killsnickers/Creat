# -*- coding: utf-8 -*-

import logging
import re

from DataFixed import DataFixed
from ConfidenceLevel import ConfidenceLevel
from WordsToNumberFixed import WordsToNumberFixed

class AmountDataFixed(DataFixed):
    """description of class"""

    def __init__(self, amount_in_words = ''):
        DataFixed.__init__(self, 'Amount')
        self._cls = 9
        self.amount_in_words = amount_in_words

    def __FixedData__(self, resultJson):
        amounts = self.__ParseData__(resultJson)

        if not len(amounts):
            logging.info('Amount Data Error')
            return ConfidenceLevel.Bad, ''

        logging.info(amounts[0] + u' Fixed To ')

        confidencelevel, amount = self.__FixedAmountData__(amounts)

        if self.amount_in_words:
            dataFixed = WordsToNumberFixed(resultJson)
            _, amount_convert = dataFixed.StartFixedFromJson(resultJson)
            if str(amount_convert) == str(amount):
                confidencelevel = ConfidenceLevel.Confident

            if amount_convert:
                amount = amount_convert

        logging.info(amount)

        return confidencelevel, amount


    def __FixedDataWithValidate__(self, resultJson, validateJson):
        result_amounts = self.__ParseData__(resultJson)
        validated_amounts = self.__ParseData__(validateJson)

        if not self.__CheckData__(validated_amounts[0]):
            logging.info(u'Validated Data Error')
            return

        if validated_amounts[0] != result_amounts[0]:
            self.__ErrorCount__ += 1
        else:
            logging.info(u'Validated Equal To Result')
            return

        logging.info(u'Validated Not Equal To Result')
        logging.info(result_amounts + u' Fixed To ')

        confidencelevel, amount = self.__FixedAmountData__(result_amounts)

        logging.info(amount)

        if validated_amounts[0] == amount:
            self.__FixedCount__ += 1
            logging.info(u'Fixed Success!')
        else:
            logging.info(u'Validated ' + validated_amounts)
            logging.info(u'Fixed Falied!')


    def __ParseData__(self, jsondata):
        amounts = []

        if jsondata == None or not isinstance(jsondata, dict) or jsondata[u'regions'] == None:
            return amounts

        regions = jsondata[u'regions']
        regions = sorted(regions, key=lambda region: region[u'confidence'], reverse = True)

        for region in regions:
            if region[u'cls'] == None or region[u'result'] == None or region[u'ref_result'] == None:
                continue

            cls = region[u'cls']
            if cls == self._cls:
                for result in region[u'result']:
                    if len(result):
                        amounts.append(result)

                for result in region[u'ref_result']:
                    if len(result):
                        amounts.append(result)

        return amounts


    def __CheckData__(self, data):
        return True


    def __FixedAmountData__(self, amounts):
        for amount in amounts:
            try:
                result = float(amount)
                if amount.find('.') == -1:
                    return ConfidenceLevel.Bad, int(result)
                else:
                    return ConfidenceLevel.Bad, u'{:.2f}'.format(result)
            except Exception:
                pass

        return ConfidenceLevel.Bad, re.sub(r'[^0-9\.]', u'', amounts[0])
