# -*- encoding: utf-8 -*-

import logging
import re

from ConfidenceLevel import ConfidenceLevel
from DataFixed import DataFixed
from utils.dateutil import parser

class DateTimeDataFixed(DataFixed):
    def __init__(self):
        DataFixed.__init__(self, u'Date Time')
        self._format = '%Y-%m-%d %H:%M'
        self.cls = 43

    def __FixedData__(self, resultJson):
        datetimes = self.__ParseData__(resultJson)
        if not len(datetimes):
            logging.info(u'Date Time Error')
            return ConfidenceLevel.Bad, ''

        logging.info(datetimes[0] + u' Fixed To ')
        datetimes = self.__TripDate__(datetimes)

        time_confidence, datetime = self.__TimeFix__(datetimes)

        logging.info(datetime)

        return time_confidence, datetime


    def __ParseData__(self, jsondata):
        datetimes = []

        if jsondata == None or not isinstance(jsondata, dict) or jsondata[u'regions'] == None:
            return datetimes

        regions = jsondata[u'regions']

        for region in regions:
            if region[u'cls'] == None or region[u'result'] == None:
                continue

            cls = region[u'cls']
            if cls == self.cls:
                for result in region[u'result']:
                    if len(result):
                        datetimes.append(result)

                if region.get(u'ref_result') != None:
                    for result in region[u'ref_result']:
                        if len(result):
                            datetimes.append(result)

        return datetimes


    def __TimeFix__(self, datetimes):
        confidence_level = ConfidenceLevel.Bad
        result = u''

        for time in datetimes:
            try:
                parse_time = parser.parse(time)
                confidence_level = ConfidenceLevel.Fixed
                result = parse_time.strftime(self._format)
                break
            except Exception:
                continue

        if result.strip():
            return confidence_level, result
        
        return ConfidenceLevel.Bad, datetimes[0]


    def __TripDate__(self, datetimes):
        result = []
        for time in datetimes:
            tripped_time = re.sub(r'O', u'0', time)
            tripped_time = re.sub(r'i|I|l|L', u'1', tripped_time)
            tripped_time = re.sub(r'[^0-9]', u'', tripped_time)
            result.append(tripped_time)

        return result