# -*- encoding: utf-8 -*-

import logging
import re

from GeneralNumberDataFixed import GeneralNumberDataFixed
from ConfidenceLevel import ConfidenceLevel

class NumberDataFixed(GeneralNumberDataFixed):
    """description of class"""

    def __init__(self):
        GeneralNumberDataFixed.__init__(self)
        self.__NumberCount__ = [8]
        self.__Cls__ = 2

    def __CheckData__(self, number):
        if len(number) == 0 or not len(number) in self.__NumberCount__:
            return False

        for ch in number:
            if not ch in self.__NumberPatterns__:
                return False

        return True

    def __ParseData__(self, jsondata):
        numberlist = []

        has_cls_1 = False
        if jsondata == None or not isinstance(jsondata, dict) or jsondata[u'regions'] == None:
            return numberlist

        regions = jsondata[u'regions']
        regions = sorted(regions, key=lambda region: region[u'confidence'], reverse = True)

        for region in regions:
            if region[u'cls'] == None or region[u'result'] == None or region[u'ref_result'] == None:
                continue

            cls = region[u'cls']
            if cls == 1:
                has_cls_1 = True
            if cls == self.__Cls__:
                for result in region[u'result']:
                    if len(result):
                        numberlist.append(result)

                for result in region[u'ref_result']:
                    if len(result):
                        numberlist.append(result)

        # cls: 1 not exist then __NumberCount__ will be 8 or 9 or 10 or 12
        if not has_cls_1:
            self.__NumberCount__ += [9, 10, 12]

        return numberlist


    def __FixedCodeData__(self, numbers):
        numbers = self.__TripSpecialChar__(numbers)

        for number in numbers:
            if self.__CheckData__(number):
                return ConfidenceLevel.Bad, number

        return ConfidenceLevel.Bad, numbers[0]

    def __TripSpecialChar__(self, codes):
        tripped_list = []
        for code in codes:
            code_removed = self.__RemoveConfusingChar__(code)
            tripped_list.append(re.sub(r'[^0-9]', u'', code_removed))

        return tripped_list

    def __RemoveConfusingChar__(self, code):
        code_removed = re.sub(r'O', u'0', code)
        code_removed = re.sub(r'i|I|l|L', u'1', code_removed)
        return code_removed
