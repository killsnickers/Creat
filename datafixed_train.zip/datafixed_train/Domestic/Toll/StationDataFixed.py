# -*- encoding: utf-8 -*-

import re
import logging

from ConfidenceLevel import ConfidenceLevel
from DataFixed import DataFixed

class StationDataFixed(DataFixed):
    def __init__(self, cls = 15):
        DataFixed.__init__(self, u'Station')
        self.cls = cls

    def __ParseData__(self, jsondata):
        stations = []

        if jsondata == None or not isinstance(jsondata, dict) or jsondata[u'regions'] == None:
            return stations

        regions = jsondata[u'regions']

        for region in regions:
            if region[u'cls'] == None or region[u'result'] == None:
                continue

            cls = region[u'cls']
            if cls == self.cls:
                for result in region[u'result']:
                    if len(result):
                        stations.append(result)

                if region.get(u'ref_result') != None:
                    for result in region[u'ref_result']:
                        if len(result):
                            stations.append(result)

        return stations

    def __FixedData__(self, resultJson):
        stations = self.__ParseData__(resultJson)

        if not len(stations):
            logging.info('station error')
            return ConfidenceLevel.Bad, ''

        logging.info(stations[0] + ' fixed to')
        confidence_level, stations = self.fixedstation(stations)

        logging.info(stations)
        return confidence_level, stations


    def fixedstation(self, stations):
        for station in stations:
            try:
                float(station)
                return ConfidenceLevel.Bad, station
            except Exception:
                break

        station = re.sub(r'[A-Z0-9]', u'', stations[0])
        return ConfidenceLevel.Bad, station