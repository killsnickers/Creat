import logging
import re

from GeneralNumberDataFixed import GeneralNumberDataFixed
from ConfidenceLevel import ConfidenceLevel

class CodeDataFixed(GeneralNumberDataFixed):
    """description of class"""

    def __init__(self):
        GeneralNumberDataFixed.__init__(self, 'Code')
        self.__NumberCount__ = 12
        self.__Cls__ = 1

    def __CheckData__(self, code):
        if len(code) == 0 or len(code) != self.__NumberCount__:
            return False

        for ch in code:
            if not ch in self.__NumberPatterns__:
                return False

        return True

    def __FixedCodeData__(self, codes):
        # has letters sometimes
        letter_count = 0
        for code in codes:
            if re.search(r'[A-Z]', code):
                letter_count += 1

        if letter_count == len(codes):
            return ConfidenceLevel.Bad, codes[0]

        codes = self.__TripSpecialChar__(codes)

        for data in codes:
            if self.__CheckData__(data):
                return ConfidenceLevel.Bad, data

        return ConfidenceLevel.Bad, codes[0][:self.__NumberCount__]

    def __TripSpecialChar__(self, codes):
        tripped_list = []
        for code in codes:
            code_removed = self.__RemoveConfusingChar__(code)
            tripped_list.append(re.sub(r'[^0-9]', u'', code_removed))

        return tripped_list

    def __RemoveConfusingChar__(self, code):
        code_removed = re.sub(r'O', u'0', code)
        code_removed = re.sub(r'i|I|l|L', u'1', code_removed)
        return code_removed