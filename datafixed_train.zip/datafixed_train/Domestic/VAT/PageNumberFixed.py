# -*- coding: utf-8 -*-

import logging
from utils import StrUtil
import re
from DataFixed import DataFixed
from ConfidenceLevel import ConfidenceLevel


class PageNumberFixed(DataFixed):
    def __init__(self):
        DataFixed.__init__(self, 'PageNumber')
        self.__WordsNumber__ = (u'一', u'二', u'三', u'四', u'五', u'六', u'七', u'八', u'九', u'十')

    def __FixedData__(self, resultJson):
        orient_codelist = self.__ParseData__(resultJson)
        if len(orient_codelist) == 0:
            logging.info(u'Code Data Error')
            return ConfidenceLevel.Bad, ''

        logging.info(orient_codelist[0] + u' Fixed To ')
        #orient_codelist = self.__ReplaceSpecialCharacter__(orient_codelist)
        #self.__NumberCount__ = self.__GuessCodeNumberCount__(orient_codelist)
        confidencelevel, code = self.__FixedCodeData__(orient_codelist)

        logging.info(code)

        return confidencelevel, code

    # 预处理json
    def __ParseData__(self, jsondata):
        codelist = []

        if jsondata == None or not isinstance(jsondata, dict) or jsondata[u'regions'] == None:
            return codelist

        regions = jsondata[u'regions']
        regions = sorted(regions, key=lambda region: region[u'confidence'], reverse=True)

        for region in regions:
            if region[u'cls'] == None or region[u'result'] == None or region[u'ref_result'] == None:
                continue

            cls = region[u'cls']
            if cls == 47:
                for result in region[u'result']:
                    if len(result):
                        codelist.append(self.__TripWhiteSpace__(result))

                for result in region[u'ref_result']:
                    if len(result):
                        codelist.append(self.__TripWhiteSpace__(result))

        return codelist


    def __FixedCodeData__(self, firstdata):

        #final_result = []
        if len(firstdata):
            for first in firstdata:
                res = re.compile(r'第(.*)联$')
                se = res.match(first)
                if se and se.group(1) in self.__WordsNumber__:
                    return ConfidenceLevel.Confident, se
                else:
                    for ch in first:
                        if ch in self.__WordsNumber__:
                            return ConfidenceLevel.Fixed,u'第'+ch+u'联'
        return ConfidenceLevel.Bad, ''


    def __TripWhiteSpace__(self, amount):
        return amount.replace(u' ', u'')
