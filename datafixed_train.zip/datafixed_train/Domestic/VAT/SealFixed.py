# -*- coding: utf-8 -*-

import logging
from DataFixed import DataFixed
from ConfidenceLevel import ConfidenceLevel

class SealFixed(DataFixed):
    def __init__(self):
        DataFixed.__init__(self, 'Seal')

    def __FixedData__(self, resultJson):
        flag = self.__ParseData__(resultJson)

        logging.info(str(flag) + u' Fixed To ')
        result = 0
        if flag:
            result = 1
        else:
            result = 0
        logging.info(result)

        return ConfidenceLevel.Fixed, result

    #预处理json
    def __ParseData__(self, jsondata):

        if jsondata == None or not isinstance(jsondata, dict) or jsondata[u'regions'] == None:
            return False

        regions = jsondata[u'regions']
        regions = sorted(regions, key=lambda region: region[u'confidence'], reverse=True)

        for region in regions:
            if region[u'cls'] == None or region[u'result'] == None or region[u'ref_result'] == None:
                continue

            cls = region[u'cls']
            if cls == 49:
                return True

        return False