# -*- coding: utf-8 -*-

import logging
from utils import StrUtil
import re
from DataFixed import DataFixed
from ConfidenceLevel import ConfidenceLevel


class TitleFixed(DataFixed):
    def __init__(self):
        DataFixed.__init__(self, 'Title')

    def __FixedData__(self, resultJson):
        orient_codelist = self.__ParseData__(resultJson)
        if len(orient_codelist) == 0:
            logging.info(u'Title'
                         u' Data Error')
            return ConfidenceLevel.Bad, ''

        logging.info(orient_codelist[0] + u' Fixed To ')
        #orient_codelist = self.__ReplaceSpecialCharacter__(orient_codelist)
        #self.__NumberCount__ = self.__GuessCodeNumberCount__(orient_codelist)
        confidencelevel, code = self.__FixedCodeData__(orient_codelist)

        logging.info(code)

        return confidencelevel, code

    # 预处理json
    def __ParseData__(self, jsondata):
        codelist = []

        if jsondata == None or not isinstance(jsondata, dict) or jsondata[u'regions'] == None:
            return codelist

        regions = jsondata[u'regions']
        regions = sorted(regions, key=lambda region: region[u'confidence'], reverse=True)

        for region in regions:
            if region[u'cls'] == None or region[u'result'] == None or region[u'ref_result'] == None:
                continue

            cls = region[u'cls']
            if cls == 48:
                for result in region[u'result']:
                    if len(result):
                        codelist.append(self.__TripWhiteSpace__(result))

                for result in region[u'ref_result']:
                    if len(result):
                        codelist.append(self.__TripWhiteSpace__(result))

        return codelist


    def __FixedCodeData__(self, firstdata):

        #final_result = []
        return ConfidenceLevel.Confident, firstdata[0]


    def __TripWhiteSpace__(self, amount):
        return amount.replace(u' ', u'')
